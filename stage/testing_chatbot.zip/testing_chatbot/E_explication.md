## test.py

Le fichier a la lancer pour commencer un test est 'test.py', je le lançais avec cette commande:
+ /opt/miniconda3/envs/amic/bin/python /opt/amic/ami_bot/testing_chatbot/test.py

Lors du lancement du fichier vous devez choisir le fichier de question ainsi que le fichier de réponse choisisez les deux fichier coresspondant, n'oublié pas de créer le fichier réponse même vide avant si vous rajoutez un fichier de question

Depuis le menu terminal vous pourrez directement choisir de lancer un test (1) ou choisir de changer de dossier de question (6), avant d'ajouter une question (2) soyez sur d'être sur le bon fichier
