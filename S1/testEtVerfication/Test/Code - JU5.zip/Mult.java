public class Mult {

    public  int multiply(int x, int y) {
	return x*y;
    }
}
